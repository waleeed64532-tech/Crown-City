Config = {}

Config.Command = 'fbiraid'
Config.StopCommand = 'fbiraidstop'
Config.Permission = 'admin' -- Change to 'user' to allow every player.
Config.BucketBase = 710000 -- Reserve this range for this resource.
Config.MaxConcurrent = 6
Config.CooldownSeconds = 15
Config.SessionTimeoutSeconds = 360
Config.HeartbeatTimeoutSeconds = 35

-- Open LSIA apron, roughly 80 m in front of QBCore's stock aircraft spawn.
-- v1.4 deliberately uses a fixed small scene, with no pad search / roof rejection.
Config.Center = vector3(-1068.34, -2946.22, 13.95)
Config.Heading = 61.0
Config.GroundFallbackTolerance = 2.5
Config.VehicleArrivalTimeout = 6500
Config.PedExitTimeout = 3500
Config.FBISquadSize = 4
Config.Hour = 4
Config.Minute = 35
Config.Weather = 'CLEAR'
Config.MusicVolume = 0.48
Config.Subtitles = true
Config.Debug = false

Config.Models = {
    Gang = 'g_m_y_mexgoon_02',
    Tactical = 's_m_y_swat_01',
    Pilot = 's_m_m_pilot_02',
    Armored = 'insurgent', -- Stock armored transport; must have at least 4 seats.
    GangCar = 'baller2',
    Helicopter = 'polmav',
    DealCase = 'prop_security_case_01',
    Crate = 'prop_box_wood02a_pu',
    Cash = 'prop_cash_case_02'
}

Config.Gang = { Health = 230, Armor = 45, Accuracy = 31, Weapon = 'WEAPON_ASSAULTRIFLE' }
Config.FBI = { Health = 250, Armor = 100, Accuracy = 47, Weapon = 'WEAPON_CARBINERIFLE' }
Config.DrivingStyle = 786468
Config.ProtectStoryActors = true -- Two gang members and two FBI leaders survive to the finale.

-- Gang vehicles are already parked. FBI make only a short 10 m approach.
Config.GangConvoy = {
    { model='GangCar', start=vector4(-10,8,0,90), park=vector4(-10,8,0,90), members={1,2,3,4} },
    { model='GangCar', start=vector4(10,8,0,270), park=vector4(10,8,0,270), members={5,6,7,8} }
}
Config.GangMarks = {
    vector3(-3,3,0), vector3(-6,2,0), vector3(-12,12,0), vector3(-16,5,0),
    vector3(3,3,0), vector3(6,2,0), vector3(12,12,0), vector3(16,5,0)
}
Config.FBIConvoy = {
    {start=vector4(-28,-14,0,270),park=vector4(-18,-14,0,270),
     marks={vector3(-13,-8,0),vector3(-16,-9,0),vector3(-21,-10,0),vector3(-22,-18,0)}},
    {start=vector4(28,-14,0,90),park=vector4(18,-14,0,90),
     marks={vector3(13,-8,0),vector3(16,-9,0),vector3(21,-10,0),vector3(22,-18,0)}}
}
Config.Aircraft = {
    {role='overwatch',model='Helicopter',start=vector4(-65,-60,55,315),speed=15,
     route={vector3(-32,-28,55),vector3(32,-28,55),vector3(32,28,55),vector3(-32,28,55)}}
}
-- Ten elevated shots. No low interior shots or per-shot visibility gate.
Config.Shots = {
    opening={
        {ms=10000,p1=vector3(-40,-45,38),p2=vector3(-30,-35,30),t1=vector3(0,2,1),t2=vector3(0,3,1),fov=52},
        {ms=9000,p1=vector3(22,18,14),p2=vector3(18,14,12),t1=vector3(0,4,1),t2=vector3(0,4,1),fov=45}
    },
    tension={{ms=11000,p1=vector3(-15,16,13),p2=vector3(-12,14,12),t1=vector3(0,4,1),t2=vector3(0,4,1),fov=42}},
    raid={{ms=16000,p1=vector3(35,-35,26),p2=vector3(28,-30,22),t1=vector3(0,-10,1),t2=vector3(0,-8,1),fov=58}},
    standoff={{ms=7000,p1=vector3(-22,-25,15),p2=vector3(-20,-22,14),t1=vector3(0,2,1),t2=vector3(0,3,1),fov=45}},
    combat={
        {ms=15000,p1=vector3(30,20,17),p2=vector3(25,17,15),t1=vector3(0,4,1),t2=vector3(0,2,1),fov=51},
        {ms=12000,p1=vector3(-60,-50,95),p2=vector3(-48,-42,85),t1=vector3(0,0,55),t2=vector3(0,0,55),fov=66},
        {ms=15000,p1=vector3(-30,-25,22),p2=vector3(-24,-20,19),t1=vector3(0,2,1),t2=vector3(0,2,1),fov=53}
    },
    ending={
        {ms=8000,p1=vector3(20,18,16),p2=vector3(23,22,19),t1=vector3(0,3,1),t2=vector3(0,3,1),fov=49},
        {ms=12000,p1=vector3(-30,-35,40),p2=vector3(-60,-65,75),t1=vector3(0,0,1),t2=vector3(0,0,1),fov=60}
    }
}
