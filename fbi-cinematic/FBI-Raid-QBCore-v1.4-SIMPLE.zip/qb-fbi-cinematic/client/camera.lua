local R=Raid
local function lerp(a,b,t) return a+(b-a)*t end
local function ease(t) t=math.max(0,math.min(1,t)); return t*t*(3-2*t) end

function R.cameraTarget(s,offset)
    if offset.z<3 then
        return R.ground(s,vector3(offset.x,offset.y,0))+vector3(0,0,math.max(1,offset.z))
    end
    return R.world(s,offset)
end

local function position(s,offset)
    local p=R.world(s,offset)
    -- Elevated preset shots over this open apron; no fragile visibility gate.
    return vector3(p.x,p.y,math.max(p.z,s.center.z+11))
end

function R.startCamera(s)
    local first=Config.Shots.opening[1]
    local p,target=position(s,first.p1),R.cameraTarget(s,first.t1)
    s.camera=CreateCam('DEFAULT_SCRIPTED_CAMERA',true)
    if s.camera==0 then error('Camera creation failed') end
    s.camPosition,s.camTarget,s.camFov=p,target,first.fov
    SetCamCoord(s.camera,p.x,p.y,p.z)
    PointCamAtCoord(s.camera,target.x,target.y,target.z)
    SetCamFov(s.camera,first.fov)
    SetCamNearClip(s.camera,0.35)
    SetCamFarClip(s.camera,1000)
    SetCamActive(s.camera,true)
    RenderScriptCams(true,false,0,true,false)
    R.thread(s,function()
        while R.live(s) do
            local shot=s.shot
            if shot then
                local t=ease((GetGameTimer()-shot.start)/shot.ms)
                local blend=1-math.exp(-8*math.min(GetFrameTime(),0.05))
                s.camPosition=lerp(s.camPosition,lerp(shot.p1,shot.p2,t),blend)
                s.camTarget=lerp(s.camTarget,lerp(shot.t1,shot.t2,t),blend)
                s.camFov=lerp(s.camFov,shot.fov,blend)
            end
            SetCamCoord(s.camera,s.camPosition.x,s.camPosition.y,s.camPosition.z)
            PointCamAtCoord(s.camera,s.camTarget.x,s.camTarget.y,s.camTarget.z)
            SetCamFov(s.camera,s.camFov)
            SetFocusPosAndVel(s.center.x,s.center.y,s.center.z,0,0,0)
            Wait(0)
        end
    end)
end

function R.playShot(s,def)
    R.ui('fade',{black=true})
    if not R.wait(s,260) then return false end
    local p1,p2=position(s,def.p1),position(s,def.p2)
    local t1,t2=R.cameraTarget(s,def.t1),R.cameraTarget(s,def.t2)
    if not R.live(s) then return false end
    s.camPosition,s.camTarget,s.camFov=p1,t1,def.fov
    SetCamCoord(s.camera,p1.x,p1.y,p1.z)
    PointCamAtCoord(s.camera,t1.x,t1.y,t1.z)
    s.shot={p1=p1,p2=p2,t1=t1,t2=t2,fov=def.fov,ms=def.ms,start=GetGameTimer()}
    R.ui('fade',{black=false})
    return R.wait(s,def.ms)
end

function R.playShots(s,stage)
    for _,shot in ipairs(Config.Shots[stage]) do if not R.playShot(s,shot) then return false end end
    return R.live(s)
end
