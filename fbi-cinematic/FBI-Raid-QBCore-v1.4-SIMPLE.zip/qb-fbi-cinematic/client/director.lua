local R = Raid

local function stage(id,title,subtitle,music)
    R.ui('stage',{id=id,title=title,subtitle=subtitle})
    if music then R.ui('music',{track=music}) end
end

local function waitConvoys(s,list)
    local deadline = GetGameTimer()+Config.VehicleArrivalTimeout+Config.PedExitTimeout+12000
    while R.live(s) and GetGameTimer()<deadline do
        local ready = true
        for _, entry in ipairs(list) do if not entry.ready then ready=false break end end
        if ready then return true end
        Wait(100)
    end
    -- Arrival precision is optional; keep the film moving if one AI task stalls.
    return R.live(s)
end

local function deal(s)
    R.thread(s,function()
        local dict = 'mp_common'
        RequestAnimDict(dict)
        local deadline = GetGameTimer()+3500
        while R.live(s) and not HasAnimDictLoaded(dict) and GetGameTimer()<deadline do Wait(0) end
        if not R.live(s) then return end
        local boss,buyer = s.gang[1].ped,s.gang[5].ped
        SetCurrentPedWeapon(boss,GetHashKey('WEAPON_UNARMED'),true)
        SetCurrentPedWeapon(buyer,GetHashKey('WEAPON_UNARMED'),true)
        TaskTurnPedToFaceEntity(boss,buyer,1500)
        TaskTurnPedToFaceEntity(buyer,boss,1500)
        if not R.wait(s,1600) then return end
        if HasAnimDictLoaded(dict) then
            TaskPlayAnim(boss,dict,'givetake1_a',4.0,-4.0,2200,0,0,false,false,false)
            TaskPlayAnim(buyer,dict,'givetake1_b',4.0,-4.0,2200,0,0,false,false,false)
            if not R.wait(s,2300) then return end
            RemoveAnimDict(dict)
        end
        TaskStandStill(boss,-1)
        TaskStandStill(buyer,-1)
    end)
end

function R.direct(s)
    stage('01','ساحة مطار لوس سانتوس',('%02d:%02d — صفقة خارج السجلات'):format(Config.Hour,Config.Minute),'tension')
    for index, entry in ipairs(s.gangCars) do R.driveDeploy(s,entry,(index-1)*2600) end
    if not R.playShots(s,'opening') or not waitConvoys(s,s.gangCars) then return end

    stage('02','شيء يتحرك في الظلام','آخر دقائق الهدوء')
    deal(s)
    R.thread(s,function()
        if not R.wait(s,9500) then return end
        TaskLookAtEntity(s.gang[7].ped,s.air[1].vehicle,6000,2048,3)
        R.caption('الحارس: لحظة… تسمعون صوت المروحية؟',4200)
    end)
    if not R.playShots(s,'tension') then return end

    stage('03','طوق FBI','فريقان — عين في السماء','raid')
    for index, entry in ipairs(s.transports) do R.driveDeploy(s,entry,(index-1)*1200) end
    R.startAir(s)
    if not R.playShots(s,'raid') or not waitConvoys(s,s.transports) then return end

    stage('04','آخر فرصة','ألقوا الأسلحة وارفعوا أيديكم')
    R.ui('radio')
    R.caption('FBI: أنتم محاصرون. ألقوا أسلحتكم وارفعوا أيديكم!',6500)
    for _, a in ipairs(s.gang) do
        SetCurrentPedWeapon(a.ped,a.weapon,true)
        local target = R.nearestTarget(a,s.fbi)
        if target then TaskAimGunAtEntity(a.ped,target,9000,false) end
    end
    for _, a in ipairs(s.fbi) do
        local target = R.nearestTarget(a,s.gang)
        if target then TaskAimGunAtEntity(a.ped,target,9000,false) end
    end
    if not R.playShots(s,'standoff') then return end

    stage('05','الاشتباك','طلقة واحدة تغيّر كل شيء','action')
    R.beginBattle(s)
    if not R.playShots(s,'combat') then return end

    stage('06','بعد العاصفة','الساحة تعود إلى الصمت','ending')
    R.finale(s)
    R.playShots(s,'ending')
end
