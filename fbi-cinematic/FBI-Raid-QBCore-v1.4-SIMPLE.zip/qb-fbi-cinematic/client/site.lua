local R=Raid

function R.chooseSite(s)
    -- A small stock airport apron replaces the container-yard search entirely.
    s.center=Config.Center
    s.heading=Config.Heading
    s.groundCache={}
    SetEntityCoordsNoOffset(s.player,s.center.x,s.center.y,s.center.z+2,false,false,false)
    SetFocusPosAndVel(s.center.x,s.center.y,s.center.z,0,0,0)
    RequestCollisionAtCoord(s.center.x,s.center.y,s.center.z)
    NewLoadSceneStartSphere(s.center.x,s.center.y,s.center.z,180,0)
    local deadline=GetGameTimer()+3500
    while R.live(s) and not IsNewLoadSceneLoaded() and GetGameTimer()<deadline do Wait(0) end
    NewLoadSceneStop()
    if not R.wait(s,700) then return false end
    R.log(('v1.4 SIMPLE scene ready: LSIA apron %.2f, %.2f, %.2f')
        :format(s.center.x,s.center.y,s.center.z))
    return true
end
