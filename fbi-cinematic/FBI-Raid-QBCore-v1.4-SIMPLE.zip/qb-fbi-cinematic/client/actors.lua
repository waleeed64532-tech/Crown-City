local R = Raid

function R.loadModel(s, name, kind)
    if not R.live(s) then error('Cancelled') end
    local hash = GetHashKey(name)
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then error('Missing model: '..name) end
    if kind == 'ped' and not IsModelAPed(hash) then error('Not a ped model: '..name) end
    if kind == 'vehicle' and not IsModelAVehicle(hash) then error('Not a vehicle model: '..name) end
    RequestModel(hash)
    s.models[hash] = true
    local deadline = GetGameTimer()+7000
    while not HasModelLoaded(hash) and R.live(s) and GetGameTimer()<deadline do Wait(0) end
    if not R.live(s) or not HasModelLoaded(hash) then error('Model loading interrupted: '..name) end
    return hash
end

function R.prepareModels(s)
    for _,key in ipairs({'Gang','Tactical','Pilot'}) do R.loadModel(s,Config.Models[key],'ped') end
    for _,lane in ipairs(Config.GangConvoy) do
        local name=Config.Models[lane.model]
        local hash=R.loadModel(s,name,'vehicle')
        if GetVehicleModelNumberOfSeats(hash)<#lane.members then error('Not enough seats: '..name) end
    end
    local armored=R.loadModel(s,Config.Models.Armored,'vehicle')
    for _,lane in ipairs(Config.FBIConvoy) do
        if GetVehicleModelNumberOfSeats(armored)<#lane.marks then error('Not enough FBI seats') end
    end
    for _,route in ipairs(Config.Aircraft) do
        local name=Config.Models[route.model]
        local hash=R.loadModel(s,name,'vehicle')
        if not IsThisModelAHeli(hash) then error('Not a helicopter: '..name) end
    end
    for _,key in ipairs({'DealCase','Crate','Cash'}) do R.loadModel(s,Config.Models[key]) end
    R.log('v1.4 Simple models ready')
end

local function own(s, entity)
    if entity == 0 or not DoesEntityExist(entity) then error('Entity creation failed') end
    s.entities[#s.entities+1] = entity
    SetEntityAsMissionEntity(entity,true,true)
    return entity
end

local function vehicle(s, name, start, armored, airborne)
    local hash = R.loadModel(s,name,'vehicle')
    local pos = airborne and R.world(s,start) or R.ground(s,start)
    if not R.live(s) then error('Cancelled') end
    -- Local entities: no ownership migration, and no combat on the public server map.
    local v = own(s,CreateVehicle(hash,pos.x,pos.y,pos.z,R.heading(start.w,s),false,false))
    if not airborne then
        -- Let a stock vehicle settle naturally if the placement query is unavailable.
        pcall(SetVehicleOnGroundProperly,v,5.0)
    end
    SetVehicleEngineOn(v,true,true,false)
    SetVehicleLights(v,2)
    SetVehicleDirtLevel(v,0)
    SetVehicleDoorsLocked(v,1)
    SetVehicleNumberPlateText(v,armored and 'FBI' or 'DOCKS')
    if armored then
        SetVehicleColours(v,0,0)
        SetVehicleExtraColours(v,0,0)
        SetVehicleTyresCanBurst(v,false)
    end
    if airborne or armored then
        -- Damage on transports should not interrupt the deployment or pilot route.
        SetEntityInvincible(v,true)
    else
        SetVehicleEngineHealth(v,1000)
        SetVehicleBodyHealth(v,1000)
        SetEntityProofs(v,false,true,true,false,false,false,false,false)
    end
    return v
end

local function agent(s, v, model, seat, team, index, leader)
    local hash = R.loadModel(s,model,'ped')
    local ped = own(s,CreatePedInsideVehicle(v,4,hash,seat,false,false))
    local stats = team == 'gang' and Config.Gang or Config.FBI
    SetEntityMaxHealth(ped,stats.Health)
    SetEntityHealth(ped,stats.Health)
    SetPedArmour(ped,stats.Armor)
    SetPedAccuracy(ped,stats.Accuracy)
    SetPedRelationshipGroupHash(ped,s.groups[team])
    SetBlockingOfNonTemporaryEvents(ped,true)
    SetPedKeepTask(ped,true)
    SetPedCanRagdoll(ped,true)
    SetPedDropsWeaponsWhenDead(ped,false)
    SetPedFleeAttributes(ped,0,false)
    SetPedCombatAttributes(ped,0,true) -- Use cover.
    SetPedCombatAttributes(ped,5,true) -- Fight while armed.
    SetPedCombatAttributes(ped,46,false) -- Do not initiate combat during setup.
    SetPedCombatAbility(ped,team == 'fbi' and 2 or 1)
    local slot = team == 'fbi' and ((index-1)%Config.FBISquadSize+1) or 0
    local role
    if team == 'gang' then
        role = index==1 and 'boss' or index==5 and 'dealer' or 'guard'
    elseif index==0 then role='pilot'
    else role=slot==1 and 'commander_driver' or slot<=3 and 'assault' or 'cover' end
    SetPedCombatMovement(ped,role=='assault' and 2 or role=='cover' and 0 or 1)
    SetPedCombatRange(ped,1)
    SetPedSeeingRange(ped,150)
    SetPedHearingRange(ped,120)
    SetPedShootRate(ped,team == 'fbi' and 90 or 70)
    SetPedSuffersCriticalHits(ped,false)
    SetDriverAbility(ped,1.0)
    SetDriverAggressiveness(ped,0.35)
    RemoveAllPedWeapons(ped,true)
    SetEntityInvincible(ped,true) -- Released for ordinary combatants at the first shot.
    return {ped=ped, team=team, role=role, index=index, leader=leader, protected=leader,
        weapon=GetHashKey(stats.Weapon), vehicle=v, seat=seat}
end

local function addProp(s, name, offset, heading)
    local hash = R.loadModel(s,name)
    local p = R.ground(s,offset)
    local obj = own(s,CreateObject(hash,p.x,p.y,p.z,false,false,false))
    SetEntityHeading(obj,R.heading(heading or 0,s))
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj,true)
    return obj
end

function R.setRelations(s, relationship)
    SetRelationshipBetweenGroups(relationship,s.groups.gang,s.groups.fbi)
    SetRelationshipBetweenGroups(relationship,s.groups.fbi,s.groups.gang)
    SetRelationshipBetweenGroups(0,s.groups.gang,s.groups.gang)
    SetRelationshipBetweenGroups(0,s.groups.fbi,s.groups.fbi)
end

function R.createActors(s)
    AddRelationshipGroup('FBI_FILM_GANG')
    AddRelationshipGroup('FBI_FILM_FBI')
    local gangGroup,fbiGroup=GetHashKey('FBI_FILM_GANG'),GetHashKey('FBI_FILM_FBI')
    s.groups.gang, s.groups.fbi = gangGroup, fbiGroup
    R.setRelations(s,3)
    local playerGroup = GetPedRelationshipGroupHash(s.player)
    for _, group in pairs(s.groups) do
        SetRelationshipBetweenGroups(3,group,playerGroup)
        SetRelationshipBetweenGroups(3,playerGroup,group)
    end
    for _, lane in ipairs(Config.GangConvoy) do
        local name = Config.Models[lane.model]
        local v = vehicle(s,name,lane.start,false,false)
        if GetVehicleModelNumberOfSeats(GetHashKey(name)) < #lane.members then
            error('Gang vehicle has insufficient seats: '..name)
        end
        local entry = {vehicle=v, lane=lane, members={}}
        for seat, index in ipairs(lane.members) do
            local story = Config.ProtectStoryActors and (index == 1 or index == 8)
            local a = agent(s,v,Config.Models.Gang,seat-2,'gang',index,story)
            a.mark = Config.GangMarks[index]
            s.gang[index] = a
            entry.members[#entry.members+1] = a
        end
        s.gangCars[#s.gangCars+1] = entry
    end
    for squad, lane in ipairs(Config.FBIConvoy) do
        local v = vehicle(s,Config.Models.Armored,lane.start,true,false)
        if GetVehicleModelNumberOfSeats(GetHashKey(Config.Models.Armored)) < #lane.marks then
            error('Not enough FBI seats: '..Config.Models.Armored)
        end
        local entry = {vehicle=v, lane=lane, members={}}
        for slot, configuredMark in ipairs(lane.marks) do
            local mark=configuredMark
            local a = agent(s,v,Config.Models.Tactical,slot-2,'fbi',#s.fbi+1,
                Config.ProtectStoryActors and slot==1)
            a.mark, a.squad = mark, squad
            s.fbi[#s.fbi+1] = a
            entry.members[#entry.members+1] = a
        end
        s.transports[#s.transports+1] = entry
    end
    for _, route in ipairs(Config.Aircraft) do
        local name = Config.Models[route.model]
        local v = vehicle(s,name,route.start,false,true)
        if not IsThisModelAHeli(GetHashKey(name)) then error('Aircraft must be a helicopter: '..name) end
        SetHeliBladesFullSpeed(v)
        if route.role ~= 'attack' then SetVehicleSearchlight(v,true,true) end
        local pilot = agent(s,v,Config.Models.Pilot,-1,'fbi',0,true)
        SetPedCanBeDraggedOut(pilot.ped,false)
        SetPedCanRagdoll(pilot.ped,false)
        local plane = {vehicle=v,pilot=pilot.ped,route=route}
        s.air[#s.air+1] = plane
        -- A real AI hover task holds the staging position until the raid cue.
        local p = R.world(s,route.start)
        TaskHeliMission(pilot.ped,v,0,0,p.x,p.y,p.z,4,12.0,10.0,-1.0,
            math.floor(route.start.z),35.0,25.0,128)
    end
    s.dealCrate = addProp(s,Config.Models.Crate,vector3(-2,4,0),20)
    addProp(s,Config.Models.DealCase,vector3(-4,5,0),95)
    addProp(s,Config.Models.Cash,vector3(0,4,0),10)
end

function R.driveDeploy(s,entry,delay)
    R.thread(s,function()
        if not R.wait(s,delay) then return end
        local vehicle,driver=entry.vehicle,entry.members[1].ped
        local park=R.ground(s,entry.lane.park)
        if #(GetEntityCoords(vehicle)-park)>3 then
            TaskVehicleMissionCoorsTarget(driver,vehicle,park.x,park.y,park.z,4,5.0,
                Config.DrivingStyle|16777216,1.5,30.0,true)
            local deadline=GetGameTimer()+Config.VehicleArrivalTimeout
            while R.live(s) and GetGameTimer()<deadline do
                if #(GetEntityCoords(vehicle)-park)<3 and GetEntitySpeed(vehicle)<2 then break end
                Wait(100)
            end
        end
        if not R.live(s) then return end
        -- Deploy where the AI stopped; exact parking is cosmetic in this small scene.
        SetVehicleHandbrake(vehicle,true)
        if not R.wait(s,500) then return end
        for _,a in ipairs(entry.members) do TaskLeaveVehicle(a.ped,vehicle,0) end
        local deadline=GetGameTimer()+Config.PedExitTimeout
        while R.live(s) and GetGameTimer()<deadline do
            local out=true
            for _,a in ipairs(entry.members) do if IsPedInAnyVehicle(a.ped,false) then out=false end end
            if out then break end
            Wait(100)
        end
        if not R.live(s) then return end
        for _,a in ipairs(entry.members) do
            if IsPedInAnyVehicle(a.ped,false) then TaskLeaveVehicle(a.ped,vehicle,16) end
            local p=R.ground(s,a.mark)
            GiveWeaponToPed(a.ped,a.weapon,500,false,true)
            SetPedInfiniteAmmo(a.ped,true,a.weapon)
            TaskGoStraightToCoord(a.ped,p.x,p.y,p.z,2.1,6500,
                GetHeadingFromVector_2d(s.center.x-p.x,s.center.y-p.y),0.5)
        end
        if not R.wait(s,6500) then return end
        for _,a in ipairs(entry.members) do TaskStandStill(a.ped,-1) end
        entry.ready=true
    end)
end

function R.startAir(s)
    for index, air in ipairs(s.air) do
        R.thread(s,function()
            if not R.wait(s,(index-1)*1500) then return end
            local waypoint = 1
            while R.live(s) do
                local offset = air.route.route[waypoint]
                local p = R.world(s,offset)
                TaskHeliMission(air.pilot,air.vehicle,0,0,p.x,p.y,p.z,4,
                    air.route.speed,14.0,-1.0,math.floor(offset.z),35.0,35.0,128)
                local deadline = GetGameTimer()+24000
                while R.live(s) and GetGameTimer()<deadline do
                    if #(GetEntityCoords(air.vehicle)-p)<24 then break end
                    Wait(250)
                end
                waypoint = waypoint % #air.route.route + 1
            end
        end)
    end
end

function R.alive(list)
    local living = {}
    for _, a in ipairs(list) do
        if DoesEntityExist(a.ped) and not IsEntityDead(a.ped) then living[#living+1] = a end
    end
    return living
end

function R.nearestTarget(a, opponents)
    local best, distance = nil, math.huge
    local p = GetEntityCoords(a.ped)
    for _, enemy in ipairs(R.alive(opponents)) do
        local d = #(GetEntityCoords(enemy.ped)-p)
        if d < distance then best, distance = enemy.ped, d end
    end
    return best
end

function R.combatTask(a, opponents)
    if IsEntityDead(a.ped) then return end
    local target = R.nearestTarget(a,opponents)
    if target then TaskCombatPed(a.ped,target,0,16) end
end

function R.beginBattle(s)
    s.battle = true
    for _, list in ipairs({s.gang,s.fbi}) do
        for _, a in ipairs(list) do
            SetEntityInvincible(a.ped,a.protected == true)
            SetPedCombatAttributes(a.ped,46,true)
        end
    end
    -- The initial shot is a gang AI task. FBI retaliation follows on a separate cue.
    local first = s.gang[2]
    TaskShootAtEntity(first.ped,s.fbi[1].ped,1200,GetHashKey('FIRING_PATTERN_BURST_FIRE'))
    R.thread(s,function()
        if not R.wait(s,950) then return end
        R.setRelations(s,5)
        for _, a in ipairs(s.gang) do R.combatTask(a,s.fbi) end
        if not R.wait(s,500) then return end
        for _, a in ipairs(s.fbi) do R.combatTask(a,s.gang) end
        -- Reissue only for idle survivors / dead targets; do not interrupt combat constantly.
        while R.live(s) and s.battle do
            for _, list in ipairs({s.gang,s.fbi}) do
                local enemies = list == s.gang and s.fbi or s.gang
                for _, a in ipairs(R.alive(list)) do
                    if not IsPedInCombat(a.ped,0) then R.combatTask(a,enemies) end
                end
            end
            R.wait(s,4000)
        end
    end)
    -- No tactical advance, particle loading or pursuit branch can stall this version.
end

function R.finale(s)
    s.battle = false
    R.setRelations(s,3)
    local livingGang, livingFBI = R.alive(s.gang), R.alive(s.fbi)
    for _, a in ipairs(livingFBI) do
        ClearPedTasksImmediately(a.ped)
        SetPedCombatAttributes(a.ped,46,false)
        TaskStandStill(a.ped,-1)
    end
    local officer = livingFBI[1]
    for _, a in ipairs(livingGang) do
        ClearPedTasksImmediately(a.ped)
        SetPedCombatAttributes(a.ped,46,false)
        RemoveAllPedWeapons(a.ped,true)
        TaskHandsUp(a.ped,30000,officer and officer.ped or 0,1500,0)
    end
    R.caption('FBI: الموقع تحت السيطرة. أمّنوا الأسلحة والمشتبه بهم.',6500)
    R.ui('result',{gangDown=#s.gang-#livingGang,fbiDown=#s.fbi-#livingFBI,suspects=#livingGang})
end
