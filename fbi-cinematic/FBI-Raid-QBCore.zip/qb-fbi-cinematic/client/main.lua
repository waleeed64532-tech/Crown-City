Raid = { current = nil, nuiReady = false }
local R = Raid
local QBCore = exports['qb-core']:GetCoreObject()

function R.live(s) return R.current == s and s.active end
function R.log(text) print(('[qb-fbi-cinematic] %s'):format(text)) end
function R.wait(s, ms)
    local untilTime = GetGameTimer() + ms
    while R.live(s) and GetGameTimer() < untilTime do Wait(0) end
    return R.live(s)
end
function R.thread(s, fn)
    CreateThread(function()
        local ok, err = xpcall(function() fn(s) end, debug.traceback)
        if not ok and R.live(s) then
            R.log(err)
            R.finish(s, 'تعذر إكمال المشهد. تفاصيل الخطأ موجودة في F8.')
        end
    end)
end
function R.ui(action, data)
    data = data or {}
    data.action = action
    SendNUIMessage(data)
end
function R.caption(text, ms)
    if Config.Subtitles then R.ui('caption', {text=text, ms=ms or 4500}) end
end
function R.world(s, offset)
    local angle = math.rad(Config.Heading)
    local x = offset.x * math.cos(angle) - offset.y * math.sin(angle)
    local y = offset.x * math.sin(angle) + offset.y * math.cos(angle)
    return s.center + vector3(x, y, offset.z)
end
function R.heading(offset) return (offset + Config.Heading) % 360 end

function R.ground(s, offset)
    local pos = R.world(s, offset)
    RequestCollisionAtCoord(pos.x, pos.y, pos.z)
    local deadline = GetGameTimer() + 4000
    repeat
        local ok, z = GetGroundZFor_3dCoord(pos.x, pos.y, s.center.z + 90.0, false)
        if ok then
            if math.abs(z - s.center.z) > 2.5 then
                error('Ground level obstructed at offset '..tostring(offset))
            end
            return vector3(pos.x, pos.y, z + 0.08)
        end
        Wait(0)
    until not R.live(s) or GetGameTimer() > deadline
    error('Ground collision not loaded at '..tostring(offset))
end

function R.probe(s, from, to, radius, flags, ignore)
    local handle = StartShapeTestCapsule(from.x,from.y,from.z,to.x,to.y,to.z,
        radius, flags or 17, ignore or PlayerPedId(), 7)
    local deadline = GetGameTimer() + 1500
    while R.live(s) and GetGameTimer() < deadline do
        local status, hit, point, normal, entity = GetShapeTestResult(handle)
        if status == 2 then return hit == true or hit == 1, point, normal, entity end
        if status == 0 then return true end -- Fail closed on an invalid probe.
        Wait(0)
    end
    return true
end

local function chooseSite(s)
    local sites = {Config.Center}
    for _, pos in ipairs(Config.FallbackCenters or {}) do sites[#sites+1] = pos end
    for _, center in ipairs(sites) do
        if not R.live(s) then return false end
        s.center = center
        SetEntityCoordsNoOffset(s.player,center.x,center.y,center.z+2,false,false,false)
        SetFocusPosAndVel(center.x,center.y,center.z,0,0,0)
        RequestCollisionAtCoord(center.x,center.y,center.z)
        NewLoadSceneStartSphere(center.x,center.y,center.z,280.0,0)
        local deadline = GetGameTimer() + 7000
        while not IsNewLoadSceneLoaded() and R.live(s) and GetGameTimer() < deadline do Wait(0) end
        NewLoadSceneStop()
        local ok, err = pcall(function()
            local convoys = {Config.GangConvoy, Config.FBIConvoy}
            for _, convoy in ipairs(convoys) do
                for _, lane in ipairs(convoy) do
                    local a, b = R.ground(s, lane.start), R.ground(s, lane.park)
                    if GetInteriorAtCoords(b.x,b.y,b.z+1) ~= 0 then error('Interior at parking mark') end
                    if R.probe(s,a+vector3(0,0,2.1),b+vector3(0,0,2.1),1.9,17) then
                        error('Blocked convoy lane')
                    end
                end
            end
            for _, mark in ipairs(Config.GangMarks) do R.ground(s, mark) end
            for _, lane in ipairs(Config.FBIConvoy) do
                for _, mark in ipairs(lane.marks) do R.ground(s, mark) end
            end
            R.ground(s, vector3(-2,4,0))
        end)
        if ok then
            R.log(('Outdoor pad selected: %.1f, %.1f, %.1f'):format(center.x,center.y,center.z))
            return true
        end
        R.log('Pad rejected: '..tostring(err))
    end
    error('No clear port pad: adjust Config.Center / FallbackCenters for your map.')
end

local weatherNames = {'EXTRASUNNY','CLEAR','CLOUDS','SMOG','FOGGY','OVERCAST','RAIN',
    'THUNDER','CLEARING','NEUTRAL','SNOW','BLIZZARD','SNOWLIGHT','XMAS','HALLOWEEN'}
local function savePlayer(s)
    local ped = s.player
    local weather
    local hash = GetPrevWeatherTypeHashName()
    for _, name in ipairs(weatherNames) do if GetHashKey(name) == hash then weather = name break end end
    s.saved = {
        coords = GetEntityCoords(ped), heading = GetEntityHeading(ped),
        visible = IsEntityVisible(ped), alpha = GetEntityAlpha(ped),
        collision = not GetEntityCollisionDisabled(ped),
        invincible = GetPlayerInvincible(PlayerId()),
        frozen = IsEntityPositionFrozen and IsEntityPositionFrozen(ped) or false,
        radar = not IsRadarHidden(), weather = weather
    }
    FreezeEntityPosition(ped,true)
    SetPlayerInvincible(PlayerId(),true)
    SetEntityVisible(ped,false,false)
    SetEntityCollision(ped,false,false)
end

local function cleanup(s)
    if s.cleaned then return end
    s.cleaned = true
    R.ui('hide')
    if s.camera then SetCamActive(s.camera,false) end
    RenderScriptCams(false,false,0,true,false)
    if s.camera then DestroyCam(s.camera,false) s.camera=nil end
    ClearFocus()
    NewLoadSceneStop()
    if s.fire then RemoveScriptFire(s.fire) s.fire=nil end
    for _, fx in ipairs(s.effects) do StopParticleFxLooped(fx,false) end
    for i = #s.entities, 1, -1 do
        local ent = s.entities[i]
        if DoesEntityExist(ent) then
            SetEntityAsMissionEntity(ent,true,true)
            DeleteEntity(ent)
        end
    end
    for _, group in pairs(s.groups) do RemoveRelationshipGroup(group) end
    for model in pairs(s.models) do SetModelAsNoLongerNeeded(model) end
    if s.saved then
        local saved, ped = s.saved, PlayerPedId()
        SetPlayerInvincible(PlayerId(),saved.invincible)
        if DoesEntityExist(ped) then
            RequestCollisionAtCoord(saved.coords.x,saved.coords.y,saved.coords.z)
            SetEntityCoordsNoOffset(ped,saved.coords.x,saved.coords.y,saved.coords.z,false,false,false)
            SetEntityHeading(ped,saved.heading)
            SetEntityCollision(ped,saved.collision,false)
            SetEntityVisible(ped,saved.visible,false)
            SetEntityAlpha(ped,saved.alpha,false)
            FreezeEntityPosition(ped,saved.frozen)
        end
        DisplayRadar(saved.radar)
        ClearOverrideWeather()
        ClearWeatherTypePersist()
        if saved.weather then SetWeatherTypeNow(saved.weather) end
        NetworkClearClockTimeOverride()
    end
end

function R.finish(s, message, alreadyReleased)
    if R.current ~= s or s.stopping then return end
    s.stopping, s.active = true, false
    s.released = alreadyReleased or s.released
    CreateThread(function()
        DoScreenFadeOut(350)
        local deadline = GetGameTimer() + 900
        while not IsScreenFadedOut() and GetGameTimer() < deadline do Wait(0) end
        -- Return to the original bucket before making the original position visible.
        if not s.released then
            TriggerServerEvent('qb-fbi-cinematic:server:finish',s.token)
            deadline = GetGameTimer() + 5000
            while not s.released and GetGameTimer() < deadline do Wait(0) end
        end
        cleanup(s)
        if R.current == s then R.current = nil end
        DoScreenFadeIn(700)
        if message then QBCore.Functions.Notify(message,'primary',6500) end
    end)
end

RegisterNUICallback('ready',function(_, cb) R.nuiReady=true cb({ok=true}) end)

RegisterNetEvent('qb-fbi-cinematic:client:released',function(token, reason)
    local s = R.current
    if not s or s.token ~= token then return end
    s.released = true
    if not s.stopping then
        R.finish(s, reason == 'timeout' and 'انتهت جلسة العرض، تمت إعادتك.' or nil,true)
    end
end)

RegisterNetEvent('qb-fbi-cinematic:client:begin',function(token)
    if R.current then TriggerServerEvent('qb-fbi-cinematic:server:finish',token) return end
    local s = {token=token, active=true, player=PlayerPedId(), center=Config.Center,
        entities={}, models={}, groups={}, effects={}, gang={}, fbi={}, air={}, transports={}, gangCars={}}
    R.current = s
    R.thread(s,function()
        while R.live(s) do
            TriggerServerEvent('qb-fbi-cinematic:server:heartbeat',s.token)
            R.wait(s,8000)
        end
    end)
    R.thread(s,function()
        local deadline = GetGameTimer() + Config.SessionTimeoutSeconds * 1000
        while R.live(s) do
            if GetGameTimer() > deadline or PlayerPedId() ~= s.player then
                R.finish(s,'انتهت جلسة المشهد.') return
            end
            R.wait(s,1000)
        end
    end)
    R.thread(s,function()
        if IsEntityDead(s.player) or IsPedInAnyVehicle(s.player,false)
            or GetInteriorFromEntity(s.player) ~= 0 then
            R.finish(s,'ابدأ المشهد وأنت على قدميك خارج المباني.') return
        end
        savePlayer(s)
        DoScreenFadeOut(450)
        R.wait(s,550)
        if not R.live(s) then return end
        chooseSite(s)
        if not R.live(s) then return end
        R.createActors(s)
        if not R.live(s) then return end
        local deadline = GetGameTimer()+5000
        while not R.nuiReady and R.live(s) and GetGameTimer()<deadline do Wait(0) end
        if not R.nuiReady then error('NUI failed to initialize') end
        R.ui('show',{volume=Config.MusicVolume})
        NetworkOverrideClockTime(Config.Hour,Config.Minute,0)
        SetOverrideWeather(Config.Weather)
        R.startCamera(s)
        DoScreenFadeIn(1000)
        R.direct(s)
        if R.live(s) then R.finish(s,'انتهى المشهد، تمت إعادتك إلى مكانك.') end
    end)
    R.thread(s,function()
        while R.live(s) do
            DisableAllControlActions(0)
            HideHudAndRadarThisFrame()
            SetPedDensityMultiplierThisFrame(0)
            SetScenarioPedDensityMultiplierThisFrame(0,0)
            SetVehicleDensityMultiplierThisFrame(0)
            SetRandomVehicleDensityMultiplierThisFrame(0)
            SetParkedVehicleDensityMultiplierThisFrame(0)
            if s.saved then
                SetEntityVisible(s.player,false,false)
                NetworkOverrideClockTime(Config.Hour,Config.Minute,0)
                SetOverrideWeather(Config.Weather)
            end
            if IsDisabledControlJustPressed(0,200) or IsDisabledControlJustPressed(0,322) then
                R.finish(s,'تم إيقاف المشهد.') return
            end
            Wait(0)
        end
    end)
end)

AddEventHandler('onResourceStop',function(name)
    if name ~= GetCurrentResourceName() then return end
    local s = R.current
    if s then
        s.active=false
        cleanup(s)
        R.current=nil
        DoScreenFadeIn(0)
    end
end)
