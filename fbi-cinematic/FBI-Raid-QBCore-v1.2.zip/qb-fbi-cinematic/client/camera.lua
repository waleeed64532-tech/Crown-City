local R = Raid
local function lerp(a,b,t) return a+(b-a)*t end
local function ease(t) t=math.max(0,math.min(1,t)) return t*t*(3-2*t) end

function R.cameraTarget(s,offset)
    if offset.z<3 then
        -- Ground-level targets must sit above pavement, or the visibility capsule
        -- hits the floor at its own origin and rejects every camera position.
        return R.ground(s,vector3(offset.x,offset.y,0))+vector3(0,0,math.max(0.9,offset.z))
    end
    return R.world(s,offset)
end

local function empty(s,p)
    -- Physical clearance avoids false interior hits from Terminal's underground interiors.
    return not R.probe(s,p-vector3(0,0,0.25),p+vector3(0,0,0.25),0.45,19)
end

local function visible(s,p,target)
    -- The close deal shot may look directly at the crate; it must not reject itself.
    return not R.probe(s,target,p,0.12,17,s.dealCrate or s.player)
end

function R.safeCamera(s,p,target)
    for _, up in ipairs({0,7,18,35,65,105}) do
        local candidate = p+vector3(0,0,up)
        if empty(s,candidate) and visible(s,candidate,target) then return candidate end
    end
    -- A shot of the outdoor site remains usable when a low angle is occluded.
    for _, up in ipairs({100,130,160}) do
        local aerial = s.center+vector3(0,-35,up)
        if empty(s,aerial) and visible(s,aerial,target) then return aerial end
    end
    error('No unobstructed camera position. Check custom port map geometry.')
end

function R.startCamera(s)
    local first = Config.Shots.opening[1]
    local target = R.cameraTarget(s,first.t1)
    local pos = R.safeCamera(s,R.world(s,first.p1),target)
    s.camera = CreateCam('DEFAULT_SCRIPTED_CAMERA',true)
    if s.camera == 0 then error('Failed to create camera') end
    s.camPosition, s.camGoal, s.camTarget, s.camFov = pos,pos,target,first.fov
    SetCamCoord(s.camera,pos.x,pos.y,pos.z)
    PointCamAtCoord(s.camera,target.x,target.y,target.z)
    SetCamFov(s.camera,first.fov)
    SetCamNearClip(s.camera,0.35)
    SetCamFarClip(s.camera,1000.0)
    SetCamActive(s.camera,true)
    RenderScriptCams(true,false,0,true,false)
    R.thread(s,function()
        while R.live(s) do
            local shot = s.shot
            if shot then
                local t = ease((GetGameTimer()-shot.start)/shot.ms)
                local desired = lerp(shot.p1,shot.p2,t)
                -- Validate the entire movement to the next goal, not just the destination.
                if empty(s,desired) and not R.probe(s,s.camPosition,desired,0.45,19) then
                    if s.shot == shot then s.camGoal = desired end
                elseif s.shot == shot then
                    -- Keep the last verified position; changing shots uses a fade.
                    if Config.Debug then R.log('Camera obstruction: holding last safe position') end
                end
            end
            R.wait(s,100)
        end
    end)
    R.thread(s,function()
        while R.live(s) do
            local shot = s.shot
            local dt = math.min(GetFrameTime(),0.05)
            local blend = 1-math.exp(-8*dt)
            s.camPosition = lerp(s.camPosition,s.camGoal,blend)
            if shot then
                local t = ease((GetGameTimer()-shot.start)/shot.ms)
                s.camTarget = lerp(s.camTarget,lerp(shot.t1,shot.t2,t),blend)
                s.camFov = lerp(s.camFov,shot.fov,blend)
            end
            SetCamCoord(s.camera,s.camPosition.x,s.camPosition.y,s.camPosition.z)
            PointCamAtCoord(s.camera,s.camTarget.x,s.camTarget.y,s.camTarget.z)
            SetCamFov(s.camera,s.camFov)
            SetFocusPosAndVel(s.center.x,s.center.y,s.center.z,0,0,0)
            Wait(0)
        end
    end)
end

function R.playShot(s,def)
    R.ui('fade',{black=true})
    if not R.wait(s,260) then return false end
    local t1,t2 = R.cameraTarget(s,def.t1),R.cameraTarget(s,def.t2)
    local p1 = R.safeCamera(s,R.world(s,def.p1),t1)
    local p2 = R.safeCamera(s,R.world(s,def.p2),t2)
    if not R.live(s) then return false end
    -- Endpoints alone are insufficient: a crane may intersect the shot path.
    if R.probe(s,p1,p2,0.45,19) then
        p1 = R.safeCamera(s,p1+vector3(0,0,35),t1)
        p2 = R.safeCamera(s,p2+vector3(0,0,35),t2)
        if R.probe(s,p1,p2,0.45,19) then p2=p1 end
    end
    if not R.live(s) then return false end
    -- Reposition only behind a soft black fade, avoiding a fly-through between shots.
    s.camPosition,s.camGoal,s.camTarget,s.camFov = p1,p1,t1,def.fov
    SetCamCoord(s.camera,p1.x,p1.y,p1.z)
    PointCamAtCoord(s.camera,t1.x,t1.y,t1.z)
    s.shot = {p1=p1,p2=p2,t1=t1,t2=t2,fov=def.fov,ms=def.ms,start=GetGameTimer()}
    R.ui('fade',{black=false})
    return R.wait(s,def.ms)
end

function R.playShots(s,stage)
    for _, def in ipairs(Config.Shots[stage]) do
        if not R.live(s) or not R.playShot(s,def) then return false end
    end
    return R.live(s)
end
