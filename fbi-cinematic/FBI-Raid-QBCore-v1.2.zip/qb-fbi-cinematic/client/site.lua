local R = Raid

local function describe(result)
    if result.reason then return result.reason end
    local p,n=result.point,result.normal
    local entity=result.entity or 0
    local model=entity~=0 and DoesEntityExist(entity) and tostring(GetEntityModel(entity)) or 'world geometry'
    return ('hit=(%.2f,%.2f,%.2f), normal=(%.2f,%.2f,%.2f), entity=%s, model=%s')
        :format(p and p.x or 0,p and p.y or 0,p and p.z or 0,
            n and n.x or 0,n and n.y or 0,n and n.z or 0,tostring(entity),model)
end

local function clear(s,jobs,label)
    for i,result in ipairs(R.probeBatch(s,jobs)) do
        if result.hit then error(label..': '..describe(result)..' ['..tostring(i)..']',0) end
    end
end

local function sky(s,p,label)
    clear(s,{{from=p+vector3(0,0,2.7),to=p+vector3(0,0,32),radius=0.10}},
        ('Roof / overhead structure at %.1f, %.1f (%s)'):format(p.x,p.y,label))
end

local function pedPoint(s,offset)
    local p=R.ground(s,offset)
    clear(s,{{from=p+vector3(0,0,0.55),to=p+vector3(0,0,1.65),radius=0.35}},
        ('Occupied ped mark at %.1f, %.1f'):format(p.x,p.y))
    sky(s,p,'ped')
    return p
end

function R.siteProfiles(s)
    if s.vehicleProfiles then return end
    s.vehicleProfiles={}
    for _,key in ipairs({'GangCar','GangVan','Armored'}) do
        local name=Config.Models[key]
        local hash=R.loadModel(s,name,'vehicle')
        local lo,hi=GetModelDimensions(hash)
        if not lo or not hi or hi.x<=lo.x or hi.y<=lo.y or hi.z<=lo.z then
            error('Invalid vehicle dimensions: '..name)
        end
        s.vehicleProfiles[key]={name=name,
            width=math.max(math.abs(lo.x),math.abs(hi.x))+0.18,
            length=math.max(math.abs(lo.y),math.abs(hi.y))+0.18,
            height=hi.z-lo.z+0.18}
    end
end

-- Small capsules tile the vehicle's swept body, rather than a tall 3.6 m-wide
-- sphere. Each segment follows sampled pavement, including both bumper ends.
local function bands(low,high,radius)
    local count=math.max(1,math.ceil((high-low)/(radius*math.sqrt(2))))
    local values={}
    for i=0,count do values[#values+1]=low+(high-low)*i/count end
    return values
end

function R.vehicleLane(s,lane,key,label)
    local body=s.vehicleProfiles[key]
    local start,park=vector3(lane.start.x,lane.start.y,0),vector3(lane.park.x,lane.park.y,0)
    local delta=park-start
    local distance=#delta
    if distance<1 then error('Convoy lane is too short: '..label,0) end
    local direction=delta*(1/distance)
    local forward=vector3(-math.sin(math.rad(lane.start.w)),math.cos(math.rad(lane.start.w)),0)
    if #(direction-forward)>0.10 or math.abs((lane.start.w-lane.park.w+180)%360-180)>1 then
        error('Convoy must use a straight aligned approach: '..label,0)
    end
    local sideways=vector3(direction.y,-direction.x,0)
    local radius=0.42
    local across=bands(-body.width+radius,body.width-radius,radius)
    local levels=bands(0.14+radius,math.max(0.14+radius,body.height-radius),radius)
    local rear=start-direction*(body.length-radius)
    local front=park+direction*(body.length-radius)
    local path=front-rear
    local steps=math.ceil(#path/7.0)
    local last
    for step=0,steps do
        if not R.live(s) then error('Cancelled',0) end
        local offset=rear+path*(step/steps)
        local p=R.ground(s,offset)
        sky(s,p,label)
        -- Cross-section ground samples reject ledges that a center-only ray misses.
        for _,edge in ipairs({-body.width,body.width}) do
            local side=R.ground(s,offset+sideways*edge)
            if math.abs(side.z-p.z)>0.30 then
                error(('Uneven vehicle footprint (%s) at %.1f, %.1f'):format(label,side.x,side.y),0)
            end
        end
        if last then
            if math.abs(last.z-p.z)>0.35 then
                error(('Ground step in convoy lane (%s) at %.1f, %.1f'):format(label,p.x,p.y),0)
            end
            local jobs={}
            local worldSide=R.world(s,sideways)-s.center
            for _,side in ipairs(across) do
                for _,height in ipairs(levels) do
                    local lift=worldSide*side+vector3(0,0,height)
                    jobs[#jobs+1]={from=last+lift,to=p+lift,radius=radius}
                end
            end
            clear(s,jobs,('Blocked convoy lane %s / %s at %.1f, %.1f; body %.2fx%.2fx%.2f')
                :format(label,body.name,p.x,p.y,body.width*2,body.length*2,body.height))
        end
        last=p
    end
    -- Cache the exact marks before scene vehicles exist.
    R.ground(s,lane.start); R.ground(s,lane.park)
end

function R.validateSite(s)
    R.siteProfiles(s)
    s.groundCache={}
    pedPoint(s,vector3(0,0,0))
    for _,mark in ipairs(Config.GangMarks) do pedPoint(s,mark) end
    for _,lane in ipairs(Config.FBIConvoy) do
        for slot,mark in ipairs(lane.marks) do
            pedPoint(s,mark)
            if slot==2 then pedPoint(s,mark*0.66) end
        end
    end
    for _,mark in ipairs({vector3(-2,4,0),vector3(-4,5,0),vector3(0,4,0),Config.EscapeMark}) do
        pedPoint(s,mark)
    end
    for index,lane in ipairs(Config.GangConvoy) do R.vehicleLane(s,lane,lane.model,'gang '..index) end
    for index,lane in ipairs(Config.FBIConvoy) do R.vehicleLane(s,lane,'Armored','FBI '..index) end
    -- Resolve ground look targets before vehicles / props can change the ground query.
    for _,shots in pairs(Config.Shots) do
        for _,shot in ipairs(shots) do
            for _,target in ipairs({shot.t1,shot.t2}) do
                if target.z<3 then R.ground(s,vector3(target.x,target.y,0)) end
            end
        end
    end
    return true
end

function R.chooseSite(s)
    R.siteProfiles(s)
    local centers={Config.Center}
    for _,pos in ipairs(Config.FallbackCenters or {}) do centers[#centers+1]=pos end
    local offsets=Config.SiteSearchOffsets or {vector3(0,0,0)}
    local turns=Config.SiteSearchTurns or {0}
    s.siteDeadline=GetGameTimer()+Config.SiteSearchTimeoutMs
    local tried,lastReason,examples=0,'none',{}
    local streamed={}
    -- Visit every broad fallback before spending the budget on small translations.
    for _,offset in ipairs(offsets) do
        for index,center in ipairs(centers) do
            if not R.live(s) then return false end
            if GetGameTimer()>=s.siteDeadline then break end
            s.center=center+offset
            SetEntityCoordsNoOffset(s.player,s.center.x,s.center.y,s.center.z+2,false,false,false)
            SetFocusPosAndVel(s.center.x,s.center.y,s.center.z,0,0,0)
            RequestCollisionAtCoord(s.center.x,s.center.y,s.center.z)
            if streamed[index]==nil then
                NewLoadSceneStartSphere(center.x,center.y,center.z,220,0)
                local deadline=math.min(GetGameTimer()+7000,s.siteDeadline)
                while not IsNewLoadSceneLoaded() and R.live(s) and GetGameTimer()<deadline do Wait(0) end
                streamed[index]=IsNewLoadSceneLoaded()
                NewLoadSceneStop()
                if not R.live(s) then return false end
                if not R.wait(s,200) then return false end
            end
            if streamed[index] then
                for _,turn in ipairs(turns) do
                    if not R.live(s) then return false end
                    if GetGameTimer()>=s.siteDeadline then break end
                    s.heading=(Config.Heading+turn)%360
                    tried=tried+1
                    local ok,err=pcall(R.validateSite,s)
                    if not R.live(s) then return false end
                    if ok then
                        s.siteDeadline=nil
                        SetEntityCoordsNoOffset(s.player,s.center.x,s.center.y,s.center.z+2,false,false,false)
                        R.log(('v1.2 Outdoor apron selected: %.1f, %.1f, %.1f; heading %.0f (%d checks)')
                            :format(s.center.x,s.center.y,s.center.z,s.heading,tried))
                        return true
                    end
                    lastReason=tostring(err)
                    local detail=('center=(%.1f,%.1f), heading=%.0f: %s'):format(s.center.x,s.center.y,s.heading,lastReason)
                    if #examples<4 then examples[#examples+1]=detail end
                    if Config.Debug then R.log('Site candidate rejected: '..detail) end
                end
            else lastReason='Map collision streaming timeout' end
        end
    end
    s.siteDeadline=nil
    for _,example in ipairs(examples) do R.log('Site diagnostic: '..example) end
    error(('v1.2 No outdoor apron after %d checks. Last reason: %s'):format(tried,lastReason),0)
end
