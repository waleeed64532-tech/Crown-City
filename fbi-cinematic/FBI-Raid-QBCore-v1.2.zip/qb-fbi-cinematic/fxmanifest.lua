fx_version 'cerulean'
game 'gta5'

author 'Cinematic resource for QBCore'
description 'Private, bot-only FBI dock raid with automatic cameras and original music'
version '1.2.0'

dependencies { 'qb-core', '/onesync' }
shared_script 'config.lua'
server_script 'server.lua'
client_scripts {
    'client/main.lua',
    'client/actors.lua',
    'client/site.lua',
    'client/camera.lua',
    'client/director.lua'
}
ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css', 'html/app.js', 'html/audio/*.ogg' }
