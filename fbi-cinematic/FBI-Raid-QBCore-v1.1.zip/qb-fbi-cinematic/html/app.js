'use strict';
const screen = document.getElementById('screen');
const title = document.getElementById('title');
const caption = document.getElementById('caption');
const fade = document.getElementById('fade');
const result = document.getElementById('result');
const soundWarning = document.getElementById('sound');
const tracks = new Set(['tension','raid','action','ending']);
let active = false, volume = .48, timers = [], titleTimer, captionTimer;
let soundGeneration = 0, playing = [], audioContext;

function timer(fn,ms) { const id = setTimeout(fn,ms); timers.push(id); return id; }
function stopAudio() {
  soundGeneration++;
  playing.forEach(a => {a.pause(); a.src = '';});
  playing = [];
}
function playMusic(track) {
  if (!active || !tracks.has(track)) return;
  const generation = ++soundGeneration;
  const previous = playing.slice();
  const audio = new Audio(`audio/${track}.ogg`);
  audio.loop = true; audio.volume = 0;
  playing.push(audio);
  const start = performance.now();
  audio.play().then(() => {if (active) soundWarning.hidden = true;}).catch(() => {
    if (active && generation === soundGeneration) soundWarning.hidden = false;
  });
  const oldVolumes = previous.map(a => a.volume);
  function crossfade(now) {
    if (!active || generation !== soundGeneration) return;
    const t = Math.min(1,(now-start)/1700);
    audio.volume = Math.min(1,volume*Math.sin(t*Math.PI/2));
    previous.forEach((a,i) => {a.volume = oldVolumes[i]*Math.cos(t*Math.PI/2);});
    if (t < 1) requestAnimationFrame(crossfade);
    else {
      previous.forEach(a => {a.pause(); a.src = '';});
      playing = [audio];
    }
  }
  requestAnimationFrame(crossfade);
}
function radio() {
  try {
    audioContext ||= new AudioContext();
    audioContext.resume();
    [0,.16].forEach(delay => {
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      const at = audioContext.currentTime + delay;
      oscillator.frequency.value = delay ? 1140 : 920;
      oscillator.type = 'sine';
      gain.gain.setValueAtTime(0,at);
      gain.gain.linearRampToValueAtTime(volume*.18,at+.012);
      gain.gain.exponentialRampToValueAtTime(.001,at+.11);
      oscillator.connect(gain).connect(audioContext.destination);
      oscillator.start(at); oscillator.stop(at+.12);
    });
  } catch (_) { /* The main score can still play if WebAudio is unavailable. */ }
}
window.addEventListener('message',({data:d}) => {
  if (!d || typeof d.action !== 'string') return;
  if (d.action === 'show') {
    active = true; screen.hidden = false;
    volume = Math.max(0,Math.min(1,Number(d.volume) || 0));
    soundWarning.hidden = true; result.classList.remove('on'); fade.classList.remove('black');
  } else if (d.action === 'hide') {
    active = false; screen.hidden = true; stopAudio();
    timers.forEach(clearTimeout); timers = [];
    title.classList.remove('on'); caption.classList.remove('on'); result.classList.remove('on');
  } else if (active && d.action === 'music') playMusic(d.track);
  else if (active && d.action === 'stage') {
    clearTimeout(titleTimer);
    document.getElementById('number').textContent = `FBI / ${d.id || ''}`;
    title.querySelector('h1').textContent = d.title || '';
    title.querySelector('p').textContent = d.subtitle || '';
    title.classList.add('on');
    titleTimer = timer(() => title.classList.remove('on'),5200);
  } else if (active && d.action === 'caption') {
    clearTimeout(captionTimer);
    caption.textContent = d.text || ''; caption.classList.add('on');
    captionTimer = timer(() => caption.classList.remove('on'),Math.max(500,Number(d.ms)||4500));
  } else if (active && d.action === 'fade') fade.classList.toggle('black',!!d.black);
  else if (active && d.action === 'radio') radio();
  else if (active && d.action === 'result') {
    result.textContent = `العصابة: ${d.gangDown} قتلى · ${d.suspects} ناجين\nFBI: ${d.fbiDown} قتلى`;
    timer(() => result.classList.add('on'),17000);
  }
});

async function ready() {
  if (typeof GetParentResourceName !== 'function') return;
  try {
    const res = await fetch(`https://${GetParentResourceName()}/ready`,{
      method:'POST',headers:{'Content-Type':'application/json'},body:'{}'
    });
    if (!res.ok) throw new Error('not ready');
  } catch (_) {setTimeout(ready,700);}
}
ready();
