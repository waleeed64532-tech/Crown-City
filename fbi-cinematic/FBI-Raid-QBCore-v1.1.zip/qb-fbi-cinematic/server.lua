local QBCore = exports['qb-core']:GetCoreObject()
local sessions, lastStart, occupied = {}, {}, {}
local sequence = 0

local function notify(src, text, kind)
    TriggerClientEvent('QBCore:Notify', src, text, kind or 'primary', 6500)
end

local function restore(src, reason)
    local session = sessions[src]
    if not session then return end
    sessions[src] = nil
    occupied[session.bucket] = nil
    if GetPlayerName(src) then
        -- Never overwrite a bucket another resource has deliberately assigned.
        if GetPlayerRoutingBucket(src) == session.bucket then
            SetPlayerRoutingBucket(src, session.previousBucket)
        end
        TriggerClientEvent('qb-fbi-cinematic:client:released', src, session.token, reason)
    end
end

QBCore.Commands.Add(Config.Command, 'مشهد مداهمة FBI سينمائي في الميناء', {}, false, function(src)
    if src == 0 then return end
    if sessions[src] then notify(src, 'المشهد يعمل بالفعل.', 'error') return end
    if GetConvar('onesync', 'off') == 'off' then
        notify(src, 'هذا الريسورس يحتاج OneSync.', 'error') return
    end
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end
    local meta = player.PlayerData.metadata or {}
    if meta.isdead or meta.inlaststand or meta.ishandcuffed then
        notify(src, 'ابدأ وأنت حي وعلى قدميك وغير مقيد.', 'error') return
    end
    local now = os.time()
    if lastStart[src] and now - lastStart[src] < Config.CooldownSeconds then
        notify(src, 'انتظر بضع ثوان قبل إعادة المشهد.', 'error') return
    end
    local bucket
    for slot = 1, Config.MaxConcurrent do
        local candidate = Config.BucketBase + slot
        if not occupied[candidate] then bucket = candidate break end
    end
    if not bucket then notify(src, 'كل جلسات العرض مشغولة، حاول بعد قليل.', 'error') return end
    sequence = sequence + 1
    local token = ('%d:%d:%d'):format(src, now, sequence)
    sessions[src] = {
        bucket = bucket, previousBucket = GetPlayerRoutingBucket(src),
        token = token, start = now, heartbeat = now
    }
    lastStart[src], occupied[bucket] = now, src
    SetRoutingBucketPopulationEnabled(bucket, false)
    SetRoutingBucketEntityLockdownMode(bucket, 'strict')
    SetPlayerRoutingBucket(src, bucket)
    TriggerClientEvent('qb-fbi-cinematic:client:begin', src, token)
end, Config.Permission)

QBCore.Commands.Add(Config.StopCommand, 'إيقاف مشهد FBI والعودة إلى مكانك', {}, false, function(src)
    if sessions[src] then restore(src, 'stopped') end
end, 'user')

RegisterNetEvent('qb-fbi-cinematic:server:heartbeat', function(token)
    local src = source
    local session = sessions[src]
    if session and token == session.token then session.heartbeat = os.time() end
end)

RegisterNetEvent('qb-fbi-cinematic:server:finish', function(token)
    local src = source
    if sessions[src] and sessions[src].token == token then restore(src, 'finished') end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local session = sessions[src]
    if session then occupied[session.bucket] = nil end
    sessions[src], lastStart[src] = nil, nil
end)

CreateThread(function()
    while true do
        Wait(5000)
        local now = os.time()
        local expired = {}
        for src, session in pairs(sessions) do
            if now - session.start > Config.SessionTimeoutSeconds
                or now - session.heartbeat > Config.HeartbeatTimeoutSeconds
                or GetPlayerRoutingBucket(src) ~= session.bucket then
                expired[#expired+1] = src
            end
        end
        for _, src in ipairs(expired) do restore(src, 'timeout') end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    local active = {}
    for src in pairs(sessions) do active[#active+1] = src end
    for _, src in ipairs(active) do restore(src, 'resource-stopped') end
end)
