local R = Raid

local function describe(result)
    if result.reason then return result.reason end
    local p,n=result.point,result.normal
    local entity=result.entity or 0
    local model=entity~=0 and DoesEntityExist(entity) and tostring(GetEntityModel(entity)) or 'world geometry'
    return ('hit=(%.2f,%.2f,%.2f), normal=(%.2f,%.2f,%.2f), entity=%s, model=%s')
        :format(p and p.x or 0,p and p.y or 0,p and p.z or 0,
            n and n.x or 0,n and n.y or 0,n and n.z or 0,tostring(entity),model)
end

local function clear(s,jobs,label)
    for i,result in ipairs(R.probeBatch(s,jobs)) do
        if result.hit then error(label..': '..describe(result)..' ['..tostring(i)..']',0) end
    end
end

local function sky(s,p,label)
    -- Overlap the ped volume: no blind gap below a 2.2 m cargo/container ceiling.
    clear(s,{{from=p+vector3(0,0,1.85),to=p+vector3(0,0,32),radius=0.10}},
        ('Roof / overhead structure at %.1f, %.1f (%s)'):format(p.x,p.y,label))
end

local function pedPoint(s,offset)
    local p=R.ground(s,offset)
    clear(s,{{from=p+vector3(0,0,0.55),to=p+vector3(0,0,1.65),radius=0.35}},
        ('Occupied ped mark at %.1f, %.1f'):format(p.x,p.y))
    sky(s,p,'ped')
    return p
end

local function outsideParking(s,mark)
    local p=vector3(mark.x,mark.y,0)
    for _,convoy in ipairs({Config.GangConvoy,Config.FBIConvoy}) do
        for _,lane in ipairs(convoy) do
            local body=s.vehicleProfiles[lane.model or 'Armored']
            local angle=math.rad(lane.park.w)
            local forward=vector3(-math.sin(angle),math.cos(angle),0)
            local side=vector3(forward.y,-forward.x,0)
            local delta=p-vector3(lane.park.x,lane.park.y,0)
            local along=delta.x*forward.x+delta.y*forward.y
            local across=delta.x*side.x+delta.y*side.y
            if math.abs(along)<body.length+0.40 and math.abs(across)<body.width+0.45 then return false end
        end
    end
    return true
end

local function findMark(s,mark,label)
    local choices={vector3(0,0,0)}
    for _,distance in ipairs({2,Config.PedMarkSearchRadius}) do
        if distance>0 then
            for i=0,7 do
                local angle=math.pi*i/4
                choices[#choices+1]=vector3(math.cos(angle)*distance,math.sin(angle)*distance,0)
            end
        end
    end
    local last='overlaps another actor / parked vehicle'
    for _,shift in ipairs(choices) do
        if not R.live(s) then error('Cancelled',0) end
        local candidate=vector3(mark.x+shift.x,mark.y+shift.y,0)
        local free=outsideParking(s,candidate)
        for _,other in ipairs(s.reservedMarks) do
            if #(candidate-other)<1.35 then free=false break end
        end
        if free then
            local ok,err=pcall(pedPoint,s,candidate)
            if ok then
                s.reservedMarks[#s.reservedMarks+1]=candidate
                return candidate
            end
            last=tostring(err)
        end
    end
    error('No clear actor position for '..label..': '..last,0)
end

function R.siteProfiles(s)
    if s.vehicleProfiles then return end
    s.vehicleProfiles={}
    for _,key in ipairs({'GangCar','GangVan','Armored'}) do
        local name=Config.Models[key]
        local hash=R.loadModel(s,name,'vehicle')
        local lo,hi=GetModelDimensions(hash)
        if not lo or not hi or hi.x<=lo.x or hi.y<=lo.y or hi.z<=lo.z then
            error('Invalid vehicle dimensions: '..name)
        end
        s.vehicleProfiles[key]={name=name,
            width=math.max(math.abs(lo.x),math.abs(hi.x))+0.18,
            length=math.max(math.abs(lo.y),math.abs(hi.y))+0.18,
            height=hi.z-lo.z+0.18}
    end
end

-- Small capsules tile the vehicle's swept body, rather than a tall 3.6 m-wide
-- sphere. Each segment follows sampled pavement, including both bumper ends.
local function bands(low,high,radius)
    local count=math.max(1,math.ceil((high-low)/(radius*math.sqrt(2))))
    local values={}
    for i=0,count do values[#values+1]=low+(high-low)*i/count end
    return values
end

function R.vehicleLane(s,lane,key,label)
    local body=s.vehicleProfiles[key]
    local start,park=vector3(lane.start.x,lane.start.y,0),vector3(lane.park.x,lane.park.y,0)
    local delta=park-start
    local distance=#delta
    if distance<1 then error('Convoy lane is too short: '..label,0) end
    local direction=delta*(1/distance)
    local forward=vector3(-math.sin(math.rad(lane.start.w)),math.cos(math.rad(lane.start.w)),0)
    if #(direction-forward)>0.10 or math.abs((lane.start.w-lane.park.w+180)%360-180)>1 then
        error('Convoy must use a straight aligned approach: '..label,0)
    end
    local sideways=vector3(direction.y,-direction.x,0)
    local radius=0.42
    local across=bands(-body.width+radius,body.width-radius,radius)
    local levels=bands(0.14+radius,math.max(0.14+radius,body.height-radius),radius)
    local rear=start-direction*(body.length-radius)
    local front=park+direction*(body.length-radius)
    local path=front-rear
    local steps=math.ceil(#path/7.0)
    local last
    for step=0,steps do
        if not R.live(s) then error('Cancelled',0) end
        local offset=rear+path*(step/steps)
        local p=R.ground(s,offset)
        sky(s,p,label)
        -- Cross-section ground samples reject ledges that a center-only ray misses.
        for _,edge in ipairs({-body.width,body.width}) do
            local side=R.ground(s,offset+sideways*edge)
            if math.abs(side.z-p.z)>0.30 then
                error(('Uneven vehicle footprint (%s) at %.1f, %.1f'):format(label,side.x,side.y),0)
            end
        end
        if last then
            if math.abs(last.z-p.z)>0.35 then
                error(('Ground step in convoy lane (%s) at %.1f, %.1f'):format(label,p.x,p.y),0)
            end
            local jobs={}
            local worldSide=R.world(s,sideways)-s.center
            for _,side in ipairs(across) do
                for _,height in ipairs(levels) do
                    local lift=worldSide*side+vector3(0,0,height)
                    jobs[#jobs+1]={from=last+lift,to=p+lift,radius=radius}
                end
            end
            clear(s,jobs,('Blocked convoy lane %s / %s at %.1f, %.1f; body %.2fx%.2fx%.2f')
                :format(label,body.name,p.x,p.y,body.width*2,body.length*2,body.height))
        end
        last=p
    end
    -- Cache the exact marks before scene vehicles exist.
    R.ground(s,lane.start); R.ground(s,lane.park)
end

function R.validateSite(s)
    R.siteProfiles(s)
    s.groundCache={}
    s.cameraTargets={}
    s.gangMarks={}; s.fbiMarks={}; s.advanceMarks={}; s.reservedMarks={}
    pedPoint(s,vector3(0,0,0))
    for _,mark in ipairs({vector3(-2,4,0),vector3(-4,5,0),vector3(0,4,0),vector3(22,8,0),Config.EscapeMark}) do
        pedPoint(s,mark)
        if mark~=Config.EscapeMark then s.reservedMarks[#s.reservedMarks+1]=mark end
    end
    for index,lane in ipairs(Config.GangConvoy) do R.vehicleLane(s,lane,lane.model,'gang '..index) end
    for index,lane in ipairs(Config.FBIConvoy) do R.vehicleLane(s,lane,'Armored','FBI '..index) end
    for index,mark in ipairs(Config.GangMarks) do s.gangMarks[index]=findMark(s,mark,'gang '..index) end
    for squad,lane in ipairs(Config.FBIConvoy) do
        s.fbiMarks[squad]={}
        s.advanceMarks[squad]={}
        for slot,mark in ipairs(lane.marks) do
            local resolved=findMark(s,mark,('FBI %d/%d'):format(squad,slot))
            s.fbiMarks[squad][slot]=resolved
            if slot==2 then
                local advanced=resolved*0.66
                -- An optional advance cannot invalidate an otherwise usable whole scene.
                if pcall(pedPoint,s,advanced) then s.advanceMarks[squad][slot]=advanced end
            end
        end
    end
    -- Verify every shot and its target before any cinematic actor exists.
    for _,shots in pairs(Config.Shots) do
        for _,shot in ipairs(shots) do
            local a=R.cameraTarget(s,shot.t1)
            local b=R.cameraTarget(s,shot.t2)
            R.safeCamera(s,R.world(s,shot.p1),a)
            R.safeCamera(s,R.world(s,shot.p2),b)
        end
    end
    return true
end

function R.groundLevels(s,estimated)
    local levels={}
    local function add(z)
        if type(z)~='number' or z~=z or math.abs(z-estimated.z)>Config.GroundCalibrationRange then return end
        for _,old in ipairs(levels) do if math.abs(old-z)<0.20 then return end end
        levels[#levels+1]=z
    end
    -- Generated native spelling varies between the current name and old Lua alias.
    local excluding=GetGroundZExcludingObjectsFor3dCoord or GetGroundZExcludingObjectsFor_3dCoord
    if excluding then
        local found,z=excluding(estimated.x,estimated.y,
            estimated.z+Config.GroundCalibrationRange,false,false)
        if found then add(z) end
    end
    local jobs={}
    for _,xy in ipairs({{0,0},{-6,0},{6,0},{0,-6},{0,6},{-10,-10},{10,-10},{-10,10},{10,10}}) do
        local x,y=estimated.x+xy[1],estimated.y+xy[2]
        RequestCollisionAtCoord(x,y,estimated.z)
        jobs[#jobs+1]={kind='ray',from=vector3(x,y,estimated.z+Config.GroundCalibrationRange),
            to=vector3(x,y,estimated.z-Config.GroundCalibrationRange),flags=17}
    end
    local heights={}
    for _,hit in ipairs(R.probeBatch(s,jobs)) do
        if not hit.reason and hit.hit and hit.point and hit.normal and hit.normal.z>=Config.GroundNormalMin then
            heights[#heights+1]=hit.point.z
        end
    end
    if #heights>0 then
        table.sort(heights)
        add(heights[math.ceil(#heights/2)])
        -- A few objects must not force the whole scene onto their roof level.
        add(heights[1])
    end
    add(estimated.z)
    return levels
end

function R.chooseSite(s)
    R.siteProfiles(s)
    local centers={Config.Center}
    for _,pos in ipairs(Config.FallbackCenters or {}) do centers[#centers+1]=pos end
    local offsets=Config.SiteSearchOffsets or {vector3(0,0,0)}
    local turns=Config.SiteSearchTurns or {0}
    s.siteDeadline=GetGameTimer()+Config.SiteSearchTimeoutMs
    local tried,lastReason,examples=0,'none',{}
    local streamed={}
    -- Visit every broad fallback before spending the budget on small translations.
    for _,offset in ipairs(offsets) do
        for index,center in ipairs(centers) do
            if not R.live(s) then return false end
            if GetGameTimer()>=s.siteDeadline then break end
            s.center=center+offset
            SetEntityCoordsNoOffset(s.player,s.center.x,s.center.y,s.center.z+2,false,false,false)
            SetFocusPosAndVel(s.center.x,s.center.y,s.center.z,0,0,0)
            RequestCollisionAtCoord(s.center.x,s.center.y,s.center.z)
            if streamed[index]==nil then
                NewLoadSceneStartSphere(center.x,center.y,center.z,220,0)
                local deadline=math.min(GetGameTimer()+7000,s.siteDeadline)
                while not IsNewLoadSceneLoaded() and R.live(s) and GetGameTimer()<deadline do Wait(0) end
                streamed[index]=IsNewLoadSceneLoaded()
                NewLoadSceneStop()
                if not R.live(s) then return false end
                if not R.wait(s,200) then return false end
            end
            if streamed[index] then
                local estimated=s.center
                local levels=R.groundLevels(s,estimated)
                for _,level in ipairs(levels) do
                  s.center=vector3(estimated.x,estimated.y,level)
                  for _,turn in ipairs(turns) do
                    if not R.live(s) then return false end
                    if GetGameTimer()>=s.siteDeadline then break end
                    s.heading=(Config.Heading+turn)%360
                    tried=tried+1
                    local ok,err=pcall(R.validateSite,s)
                    if not R.live(s) then return false end
                    if ok then
                        s.siteDeadline=nil
                        SetEntityCoordsNoOffset(s.player,s.center.x,s.center.y,s.center.z+2,false,false,false)
                        R.log(('v1.3 Outdoor apron selected: %.1f, %.1f, %.2f; heading %.0f (%d checks); physical ground verified')
                            :format(s.center.x,s.center.y,s.center.z,s.heading,tried))
                        R.log('v1.3 Preflight passed: 6 ground vehicle lanes, 25 actor positions, 20 camera shots')
                        return true
                    end
                    lastReason=tostring(err)
                    local detail=('center=(%.1f,%.1f,%.2f), heading=%.0f: %s'):format(s.center.x,s.center.y,s.center.z,s.heading,lastReason)
                    if #examples<4 then examples[#examples+1]=detail end
                    if Config.Debug then R.log('Site candidate rejected: '..detail) end
                end
                end
            else lastReason='Map collision streaming timeout' end
        end
    end
    s.siteDeadline=nil
    for _,example in ipairs(examples) do R.log('Site diagnostic: '..example) end
    error(('v1.3 No outdoor apron after %d checks. Last reason: %s'):format(tried,lastReason),0)
end
