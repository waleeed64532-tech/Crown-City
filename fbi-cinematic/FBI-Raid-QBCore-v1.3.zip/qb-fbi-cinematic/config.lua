Config = {}

Config.Command = 'fbiraid'
Config.StopCommand = 'fbiraidstop'
Config.Permission = 'admin' -- Change to 'user' to allow every player.
Config.BucketBase = 710000 -- Reserve this range for this resource.
Config.MaxConcurrent = 6
Config.CooldownSeconds = 15
Config.SessionTimeoutSeconds = 360
Config.HeartbeatTimeoutSeconds = 35

-- Compact layout on the Terminal outdoor apron. All positions are relative.
Config.Center = vector3(1000.0, -3264.0, 5.9)
Config.FallbackCenters = {
    vector3(960,-3264,5.9), vector3(1040,-3264,5.9),
    vector3(920,-3264,5.9), vector3(1080,-3264,5.9),
    vector3(880,-3264,5.9), vector3(1120,-3264,5.9)
}
Config.SiteSearchOffsets = {
    vector3(0,0,0), vector3(0,-8,0), vector3(0,8,0),
    vector3(-8,0,0), vector3(8,0,0), vector3(0,-16,0),
    vector3(0,16,0), vector3(-16,0,0), vector3(16,0,0)
}
Config.SiteSearchTurns = {0,180} -- Rotate actors, routes and cameras together.
Config.SiteSearchTimeoutMs = 60000
Config.GroundTolerance = 1.6
Config.GroundCalibrationRange = 6.0 -- Estimated Z is a hint; physical rays calibrate it.
Config.GroundTraceUp = 1.0 -- Keep point rays below nearby container / cargo roofs.
Config.GroundTraceDown = 2.0
Config.GroundNormalMin = 0.94
Config.PedMarkSearchRadius = 4.0
Config.Heading = 0.0
Config.Hour = 4
Config.Minute = 35
Config.Weather = 'CLEAR'
Config.MusicVolume = 0.48
Config.Subtitles = true
Config.Debug = false

Config.Models = {
    Gang = 'g_m_y_mexgoon_02',
    Tactical = 's_m_y_swat_01',
    Pilot = 's_m_m_pilot_02',
    Armored = 'insurgent', -- Stock armored transport; must have at least 5 seats.
    GangCar = 'baller2',
    GangVan = 'speedo',
    Helicopter = 'polmav',
    AttackHelicopter = 'hunter', -- Stock AH-64-style alternative, not a custom Apache.
    ApacheAddon = '', -- Put the installed custom Apache SPAWN NAME here, e.g. 'ah64d'.
    DealCase = 'prop_security_case_01',
    Crate = 'prop_box_wood02a_pu',
    Cash = 'prop_cash_case_02'
}

Config.Gang = { Health = 230, Armor = 45, Accuracy = 31, Weapon = 'WEAPON_ASSAULTRIFLE' }
Config.FBI = { Health = 250, Armor = 100, Accuracy = 47, Weapon = 'WEAPON_CARBINERIFLE' }
Config.DrivingStyle = 786468
Config.VehicleArrivalTimeout = 28000
Config.PedExitTimeout = 6500
Config.ProtectStoryActors = true -- Gang boss, runner and three FBI leaders survive to the finale.
Config.EscapeMark = vector3(20,22,0) -- Remains on the apron, short of the container stacks.

-- Separate approach lanes: no car must pass another car's final parking spot.
Config.GangConvoy = {
    { model = 'GangCar', start = vector4(-62, 8, 0, 270), park = vector4(-17, 8, 0, 270), members = {1, 2, 3, 4} },
    { model = 'GangVan', start = vector4(0, 30, 0, 180), park = vector4(0, 14, 0, 180), members = {5, 6} },
    { model = 'GangCar', start = vector4(62, 8, 0, 90), park = vector4(18, 8, 0, 90), members = {7, 8, 9, 10} }
}

Config.GangMarks = {
    vector3(-4, 4, 0), vector3(-8, 7, 0), vector3(-18, 11, 0), vector3(-21, 3, 0),
    vector3(3, 3, 0), vector3(5, 11, 0), vector3(14, 3, 0), vector3(24, 10, 0),
    vector3(20, 15, 0), vector3(10, 17, 0)
}

-- Three converging lanes, five agents per transport (the driver also deploys).
Config.FBIConvoy = {
    { start = vector4(-64, -18, 0, 270), park = vector4(-32, -18, 0, 270),
      marks = {vector3(-29,-12,0), vector3(-27,-17,0), vector3(-34,-12,0), vector3(-31,-24,0), vector3(-38,-18,0)} },
    { start = vector4(64, -12, 0, 90), park = vector4(34, -12, 0, 90),
      marks = {vector3(29,-8,0), vector3(29,-16,0), vector3(37,-6,0), vector3(36,-19,0), vector3(40,-12,0)} },
    { start = vector4(10, -44, 0, 0), park = vector4(10, -29, 0, 0),
      marks = {vector3(4,-25,0), vector3(16,-25,0), vector3(4,-33,0), vector3(16,-33,0), vector3(10,-36,0)} }
}

Config.Aircraft = {
    { role = 'overwatch', model = 'Helicopter', start = vector4(-190,-180,90,315), speed = 18,
      route = {vector3(-65,-55,90), vector3(65,-55,90), vector3(65,60,90), vector3(-65,60,90)} },
    { role = 'perimeter', model = 'Helicopter', start = vector4(210,185,115,135), speed = 18,
      route = {vector3(90,75,115), vector3(-90,75,115), vector3(-90,-75,115), vector3(90,-75,115)} },
    { role = 'attack', model = 'AttackHelicopter', start = vector4(-260,20,80,270), speed = 30,
      route = {vector3(-130,20,72), vector3(130,20,72), vector3(145,145,130), vector3(-145,145,130)} }
}

-- Camera paths are bounded. Between different shots the director uses a soft fade.
-- p1 / p2 = camera start / finish, t1 / t2 = look target start / finish.
Config.Shots = {
    opening = {
        {ms=9500, p1=vector3(-85,-95,90), p2=vector3(-55,-72,70), t1=vector3(0,7,0), t2=vector3(0,7,0), fov=58},
        {ms=8500, p1=vector3(62,32,17), p2=vector3(40,24,14), t1=vector3(0,12,1), t2=vector3(0,8,1), fov=53},
        {ms=9000, p1=vector3(-32,-7,10), p2=vector3(-26,-9,9), t1=vector3(-4,4,1), t2=vector3(-4,4,1), fov=46}
    },
    tension = {
        {ms=7500, p1=vector3(-12,-3,4.5), p2=vector3(-9,-3,4), t1=vector3(-2,4,1.2), t2=vector3(-2,4,1.2), fov=41},
        {ms=6500, p1=vector3(30,22,9), p2=vector3(28,18,8), t1=vector3(20,15,1.5), t2=vector3(20,15,1.5), fov=45},
        {ms=5000, p1=vector3(-45,-60,35), p2=vector3(-42,-54,31), t1=vector3(-65,-18,1), t2=vector3(-45,-18,1), fov=57}
    },
    raid = {
        {ms=8500, p1=vector3(-65,-65,43), p2=vector3(-50,-57,35), t1=vector3(0,-15,1), t2=vector3(0,-15,1), fov=64},
        {ms=8000, p1=vector3(48,-35,15), p2=vector3(43,-30,13), t1=vector3(31,-12,1), t2=vector3(31,-12,1), fov=52},
        {ms=7500, p1=vector3(-112,-93,147), p2=vector3(-88,-80,136), t1=vector3(0,0,85), t2=vector3(5,10,72), fov=67}
    },
    standoff = {
        {ms=9000, p1=vector3(-39,-29,13), p2=vector3(-34,-25,11), t1=vector3(-5,3,1), t2=vector3(-5,3,1), fov=45}
    },
    combat = {
        {ms=9500, p1=vector3(-43,-22,13), p2=vector3(-38,-18,11), t1=vector3(-4,4,1), t2=vector3(0,5,1), fov=51},
        {ms=9000, p1=vector3(35,34,19), p2=vector3(31,29,17), t1=vector3(8,8,1), t2=vector3(4,4,1), fov=56},
        {ms=9000, p1=vector3(-65,6,17), p2=vector3(-57,3,15), t1=vector3(-12,-4,1), t2=vector3(-7,-3,1), fov=52},
        {ms=9500, p1=vector3(68,-54,33), p2=vector3(60,-47,30), t1=vector3(5,4,1), t2=vector3(5,4,1), fov=57},
        {ms=10000, p1=vector3(5,-100,112), p2=vector3(0,-85,102), t1=vector3(0,8,72), t2=vector3(0,8,72), fov=67},
        {ms=9000, p1=vector3(-46,-48,21), p2=vector3(-40,-42,18), t1=vector3(0,3,1), t2=vector3(0,3,1), fov=48},
        {ms=9000, p1=vector3(0,-22,72), p2=vector3(6,-14,80), t1=vector3(0,0,0), t2=vector3(0,0,0), fov=61}
    },
    ending = {
        {ms=7500, p1=vector3(-23,-12,9), p2=vector3(-20,-10,8), t1=vector3(-4,4,1), t2=vector3(-4,4,1), fov=45},
        {ms=7000, p1=vector3(25,32,20), p2=vector3(27,39,23), t1=vector3(10,17,1), t2=Config.EscapeMark+vector3(0,0,1), fov=55},
        {ms=10500, p1=vector3(-55,-65,69), p2=vector3(-95,-105,108), t1=vector3(0,3,0), t2=vector3(0,3,0), fov=60}
    }
}
